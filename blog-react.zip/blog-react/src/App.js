import {React} from 'react';
import Posts from './components/Posts';
import PostDetails from './components/PostDetails';
import UserDetails from './components/UserDetails';
import {Route, Switch} from 'react-router-dom';
import './App.css';

function App() {

  

  return (<>
    <Switch>
      <Route path="/" component={Posts} exact />
      <Route path="/postdetails" component={PostDetails} />
      <Route path="/userdetails" component={UserDetails} />
    </Switch></>);
}

export default App;
