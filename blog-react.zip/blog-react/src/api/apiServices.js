
const axios = require('axios').default;


export async function getPosts() {
  try {
    const response = await axios.get('http://jsonplaceholder.typicode.com/posts');
    return response.data;
  } catch (error) {
    console.error(error);
  }
};

export async function getPostDetails(postId) {
  try {
    const response = await axios.get(`http://jsonplaceholder.typicode.com/posts/${postId}`);
    return response.data;
  } catch (error) {
    console.error(error);
  }
};

export async function getUserDetails(userId) {
  try {
    const response = await axios.get(`http://jsonplaceholder.typicode.com/users/${userId}`);
    return response.data;
  } catch (error) {
    console.error(error);
  }
};



// http://jsonplaceholder.typicode.com/users/1

