import {React, useEffect, useState} from 'react';
import {getPostDetails, getUserDetails} from '../api/apiServices';
import {locationsImg} from '../assets/images';
import {Link} from 'react-router-dom';
 
function PostDetails() {

  const getUrl = window.location.href.split('/');
  const getPostId = getUrl[getUrl.length - 1];

  const [appLoading, setAppLoading] = useState(true);
  const [postDetails, setPostDetails] = useState({});
  const [userDetails, setUserDetails] = useState({});
    
  useEffect(() => {

    setAppLoading({loading: true});
    getPostDetails(getPostId).then((data) => {
      setPostDetails(data);
      setAppLoading(false);
    });

    getUserDetails(postDetails.id).then((data) => {
      setUserDetails(data);
      setAppLoading(false);
    });
   

  }, [setAppLoading, getPostId, postDetails.id]);
 
  return(appLoading ? "Loading..." :
    <div className="col-6 card card-img-size-details">
      <img className="card-img-top" src={locationsImg[postDetails.id]} alt="Travel Destinations" />
      <div className="card-body">
        <h5 className="card-title"><u>Title</u>: {postDetails.title}</h5>
        <p className="card-text">
          <u>Details</u>: {postDetails.body}
        </p>
        <Link className="nav-link" to={`/userdetails`}>
          About the author {userDetails && `- ${userDetails.name}`} 
        </Link>
      </div>            
    </div> 
  );
}
 
export default PostDetails;