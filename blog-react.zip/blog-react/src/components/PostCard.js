import {React} from 'react';
import {locationsImg} from '../assets/images';
import {Link} from 'react-router-dom';
import '../App.css';

function PostCard(props) {

  const linkTo = `/postdetails/${props.userId}`;

  return (

    <div className="col-4 card m-2 card-img-size" style={{width: "18rem"}}>
      <img className="card-img-top mt-2" src={locationsImg[props.img]} alt="Travel Destinations" />
      <div className="card-body">
        <h5 className="card-title text-truncate">{props.title}</h5>
        <p className="card-text text-truncate">
          {props.body}
        </p>
        <Link className="nav-link" to={linkTo}>
          <button className="btn btn-primary">View Post</button> 
        </Link>
      </div>            
    </div> 

  );
}

export default PostCard;
