
import {React, useEffect, useState} from 'react';
import {getPosts} from '../api/apiServices';
import PostCard from './PostCard';
 
function Posts() {

  const [appLoading, setAppLoading] = useState(true);
  const [posts, setPosts] = useState([]);
    
  useEffect(() => {

    setAppLoading({ loading: true });
    getPosts().then((data) => {
      data = data.slice(0, 10)
      setPosts(data);
      setAppLoading(false);
    });

  }, [setAppLoading]);

  return(
  
  <div className="container">
    <div className="row justify-content-md-center">
      {appLoading ? "Loading..." :
        posts.map((post, i) => (
          <PostCard
          key={i}
          title={posts[i].title}
          body={posts[i].body}
          img={post.id}
          userId={post.id}
        />
      ))}
    </div>
  </div>
  
  );

}
 
export default Posts;