import React from 'react';
import {Link } from 'react-router-dom';
 
function Header() {

  return(
    <ul className="nav justify-content-center mt-2 mb-4 pt-2 pb-2">
      <li className="nav-item">
        <Link className="nav-link" to="/">All Posts</Link>
      </li>
    </ul>
  );

};
 
export default Header;