import {React, useEffect, useState} from 'react';
import {getUserDetails} from '../api/apiServices';
 
function UserDetails() {

  const getUrl = window.location.href.split('/');
  const getPostId = getUrl[getUrl.length - 1];

  const [appLoading, setAppLoading] = useState(true);
  const [userDetails, setUserDetails] = useState({});
    
  useEffect(() => {

    setAppLoading({loading: true});

    getUserDetails(2).then((data) => {
      setUserDetails(data);
      setAppLoading(false);
    });
   

  }, [setAppLoading, getPostId]);
 
  return(appLoading ? "Loading..." :
    <div className="col-6 card card-img-size-details">
      <div className="card-body">
        <h5 className="card-title">Name: {userDetails.name}</h5>
        <p className="card-text">
          Email: {userDetails.email}<br />
          Website: {userDetails.website}<br />
          Location: {userDetails.address.city}
        </p>
      </div>            
    </div> 
  );
}
 
export default UserDetails;